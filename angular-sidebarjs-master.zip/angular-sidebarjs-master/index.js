require('./dist/angular-sidebarjs.js');

module.exports = 'ngSidebarJS';
